# Preliminary CZX research manuscript

The separately delivered article is a four-page REVTeX 4.2 PDF. Its SHA-256
is `39a1ed727738656fff2a777ce416431ff841bd3e2cb014a87c8e5a4dda3deb44`. `main.tex` is the matching editable source. It gives an
AI-assisted candidate proof; it has not been independently checked by a
human specialist, and priority and PRL suitability remain unresolved.
The author line is a placeholder. No article has been submitted.

The proposed quantitative result is specific to the CZX representative.
The earlier Lessa-Cheng-Wang PRX paper already gave the conjectured
constant and attaining bases. Existing three-qubit results already contain
the noise threshold, witness, and relative-entropy formula; this manuscript
states the ring/partition lift and attributes those antecedents. The sitewise
phase-flip threshold concerns only the specified channel; it is not a
generic local-noise or finite-depth threshold. The result does not prove
genuine multipartite entanglement.

## Reproducibility

The main article contains the all-size analytic arguments. From this folder,
the following require only a standard Python 3 installation:

    python diagnostics/verify_czx.py
    python diagnostics/check_czx.py
    python diagnostics/check_disconnected.py
    python diagnostics/check_czx_exact.py

The optional symbolic diagnostic `python diagnostics/check_robustness.py`
requires SymPy. It checks the eight-product-state decomposition and the
realignment spectrum; it does not need the other scripts. These finite
checks and the internal AI-assisted audits do not replace the all-size proof,
independent human review, or a complete literature search.

`proof-notes.md` provides a longer derivation; `leakage-bound-audit.md`
examines approximate sector symmetry; `prior-literature.md` records a
bounded priority search and distinguishes prior results from the proposed
new result. Paths in those historical notes may refer to the workspace;
the commands above use the packaged files.

OpenAI Codex, including GPT-6.1 Terra subagents, assisted with derivation,
literature search, checking and manuscript preparation under user direction.
The prospective human author must review the research and complete any
publication disclosure and authorship information.
