# Candidate exact entropy bound for a CZX-symmetric sector

Research note, 27 October 2026. The target is the quantitative conjecture
of Lessa, Cheng and Wang, *Mixed-State Quantum Anomaly and Multipartite
Entanglement*, Phys. Rev. X **15**, 011069 (2025), Appendix A, equations
(A1)–(A8): https://arxiv.org/html/2401.17357#A1. The paper already proves
tripartite nonseparability and constructs minimizing-candidate bases. This
note supplies a candidate lower-bound proof and a weighted extension; it
does not claim the model, the entanglement measure, or the attaining
states are new. Independent expert verification and a systematic priority
search remain outstanding.

## Setup and precise claim

Let L>=4 be even. The Hilbert space is a ring of L qubits, with

    U = (product_i X_i)(product_i CZ_(i,i+1)),  U^2=1.

The product of CZ gates acts first. Let A,B,C be three nonempty connected
arcs that partition the whole ring. For nonnegative weights w_A,w_B,w_C,
define the pure-state quantity

    F_w(|psi>) = sum_R w_R S(rho_R),

where natural logarithms are used and rho_R is the reduced density matrix.
For mixed rho, define F_w by its pure-state convex roof. Write

    h = -p log p - (1-p) log(1-p),  p=(2+sqrt(2))/4,
    W=w_A+w_B+w_C,  w_max=max_R w_R.

If rho is strongly symmetric, U rho = lambda rho with lambda=+1 or -1,
then

    F_w(rho) >= min{(W-w_max) log(2), W h}.                 (1)

Both branches are achievable by a strongly symmetric pure state, and the
convex roof on either maximally mixed charge sector is

    F_w((I+lambda U)/2^L)
      = min{(W-w_max) log(2), W h}.                         (2)

For w_A=w_B=w_C=1/2, (1) gives the conjectured sharp value of Appendix A:

    E_3 >= (3/2) h = 0.624743296049531... 
                       = 0.901314055039284... log(2).       (3)

The lower bound holds for every strongly symmetric rho; (2) asserts
equality only for the normalized projector onto a full charge sector.
It does not apply to the full infinite-temperature state I/2^L, weak
symmetry alone, or arbitrary anomalous symmetries. Disconnected regions
need the separate parity condition derived below.

The symmetry is the standard anomalous CZX boundary action. For an open
interval I of n>=2 sites, restrict it as
U_I=(product_(i in I) X_i)(product_(edges within I) CZ). Directly,
U_I^2=(-1)^(n-1) Z_left Z_right, whereas
U_I Z_left U_I^dagger=-Z_left. In the usual endpoint reduction this gives
the nontrivial cocycle omega(g,g,g)=-1 in H^3(Z_2,U(1))=Z_2; see
Else and Nayak, https://arxiv.org/abs/1409.5436. This identifies the
physical anomaly of this model; the entropy proof itself is finite
dimensional and does not assume a particular Hamiltonian or CFT.

## Reduction to three encoded qubits

In the computational basis,

    U|b_1...b_L> = (-1)^(sum_i b_i b_(i+1)) |bar b_1...bar b_L>.

For each region R and each complement pair {alpha,bar alpha}, let
P_R^alpha=|alpha><alpha|+|bar alpha><bar alpha|. These are local projective
measurements, and each P_R^alpha commutes with U. Hence, each nonzero
outcome applied to a pure U-eigenstate remains in the same charge sector.

To see that averaging these measurements cannot increase F_w, consider a
pure state and one measurement on A. The average reduced states on B and
C are unchanged; concavity of entropy gives S(rho_B)>=sum p_j S(rho_B^j)
and likewise for C. For A, the same inequality follows by using the
complement BC, whose average state is unchanged, and purity of each
postmeasurement state. Iterate across A,B,C. Thus the initial F_w is at
least the average F_w of the postmeasurement pure states.

On one outcome, each region is encoded by its complementary pair, so the
block has three qubits with coordinates x,y,z. Because each pair of
connected arcs shares exactly one physical edge, the computational phase
is

    q(x,y,z)=q0+ell_A x+ell_B y+ell_C z+xy+yz+zx  (mod 2).

The evenness of L gives q(x,y,z)=q(1-x,1-y,1-z), hence
ell_A+ell_B+ell_C=1 mod 2. Conjugating by the encoded X_i flips the
other two ell coefficients; thus local encoded X operations transform
every odd ell to (1,0,0), up to a global sign. The corresponding
three-qubit operator is

    U_100 |xyz> = (-1)^(x+xy+yz+zx) |1-x,1-y,1-z>.

If S_A=diag(1,i) on the encoded A qubit and

    V = i X_A X_B X_C CZ_AB CZ_BC CZ_CA,

then S_A V S_A^dagger = -U_100. Consequently every block is related by
local unitaries to an eigenspace of the permutation-symmetric V. Local
Z_A exchanges its two sectors.

## Pairwise Bloch constraint and entropy optimization

For a pure V-eigenstate, V Z_R V^dagger=-Z_R implies <Z_R>=0. Let r_R be
the Bloch-vector length of encoded qubit R and choose a unit XY-plane
observable M_R=a_R X_R+b_R Y_R with <M_R>=r_R (arbitrarily if r_R=0).
The relation

    V M_A V^dagger = (a_A X_A-b_A Y_A) Z_B Z_C

shows that V M_A V^dagger and M_B anticommute and both square to I. Their
expectations on a V-eigenstate are r_A,r_B; therefore

    r_A^2+r_B^2 <= 1,

with cyclic permutations. Put x_R=r_R^2. Then x lies in the polytope
x_i>=0, x_i+x_j<=1. Its vertices are the origin, the three coordinate
unit vectors, and (1/2,1/2,1/2). Indeed, with m=min_i x_i, one has the
convex decomposition

    x = [1-(sum_i x_i-m)] 0
      + sum_i (x_i-m) e_i + 2m(1/2,1/2,1/2).

The coefficients are nonnegative because sum_i x_i-m is the sum of the
two largest coordinates. The single-qubit entropy as a function of x is

    f(x) = h_2((1+sqrt(x))/2)
         = log 2 - sum_(n>=1) x^n/[2n(2n-1)].

It is concave on [0,1]. Therefore sum_i w_i f(x_i) is concave for
nonnegative w_i, and its minimum on the polytope is attained at a vertex.
The origin has value W log 2; the three unit vertices have values
(W-w_i) log 2; and the central vertex has value W h. This proves (1) for
each postmeasurement block and, by the previous step, for every symmetric
pure state.

## Saturation and mixed states

In the U_100=+1 sector, the normalized encoded vector

    (1,1,1,i,-i,1,1,1)/sqrt(8)

is in computational order 000,001,010,011,100,101,110,111. Its three
reduced density matrices have eigenvalues p and 1-p. For L=4 with A the
first two sites and B,C the last two, it is

    (|0000>+|0001>+|0010>+i|0011>
      -i|1100>+|1101>+|1110>+|1111>)/sqrt(8).

It is a +1 eigenstate of the physical U. Multiplying this vector by the
four encoded local operations I,Z_A Z_B,Z_A Z_C,Z_B Z_C gives an
orthonormal basis of the +1 eigenspace, all with the same reduced
entropies. Z_A switches to the -1 eigenspace.

For the coordinate vertex x_C=1, a +1-sector orthonormal basis, with
normalization 1/2 and the same computational order, is

    (1, 1,0,0, 0,0, 1,1),     (1,-1,0,0, 0,0,-1,1),
    (0, 0,1,i,-i,1,0,0),      (0, 0,1,-i,i,1,0,0).

Every member is product across C versus AB, with C pure and A and B
maximally mixed. Permuting encoded parties in the V representation and
conjugating back supplies such bases for the other coordinate vertices.
Local unitaries transport these bases to every physical orbit block.
Consequently either candidate branch admits a full basis of the given
charge sector, whose uniform mixture is (I+lambda U)/2^L. This proves
the upper bound in (2), and the lower bound follows from (1).

For an arbitrary mixed rho in a single charge sector, every pure vector
in every ensemble decomposition is in that sector: rho has no support on
the other sector, and positivity forbids cancellation. Taking the convex
roof therefore preserves the lower bound. In the unweighted case the
central value is strictly smaller than log 2, since
h<=log 2-1/4 and log 2<3/4. When W>0, the weighted crossover is at
w_max/W = 1-h/log 2 = 0.39912396330714... .

## Odd L

The source also notes the odd-L rephasing. For every odd L>=3, U^2=-1
and the same claims hold for the operator Uhat=iU and charge lambda=+/-1.
In an orbit block the quadratic phase still has the above form, but now
ell_A+ell_B+ell_C=0 mod 2. Conjugating Uhat by S_A changes its phase to
(-1)^(q(x,y,z)+x+1), and thereby changes ell_A by 1. The resulting
operator has the odd-parity linear coefficient vector needed for the
even-L reduction, again up to a scalar sign. The local projection,
Bloch-vector, convex-roof and saturation arguments then apply verbatim.
The distinction between U and Uhat is important: the original odd-L
operator has eigenvalues +/-i, not +/-1.

## Arbitrary tripartitions: an edge-parity dichotomy

The connected-arc hypothesis has an exact extension that also explains
some disconnected examples. Give each site one of three nonempty labels
A,B,C, without assuming the regions are connected. Let e_AB be the number
of ring edges with endpoints in A and B, modulo 2, and similarly define
e_BC,e_CA. Every region has an even number of boundary edges on a ring,
so

    e_AB=e_BC=e_CA=:e in {0,1}.

Local complement-pair measurements still commute with the symmetry, and
on every outcome the phase has the form

    q(x,y,z)=q0+ell_A x+ell_B y+ell_C z
                     +e(xy+yz+zx)       (mod 2).

When e=1, this is the same triangle as above, and the whole proof of
(1)–(2), including odd-L rephasing, remains valid. When e=0, the
rephased block operator factors as

    Uhat_block = i^(L mod 2) (-1)^q0
                       tensor_R (X_R Z_R^ell_R)
               = +/- tensor_R M_R,

where M_R=X_R for ell_R=0 and M_R=Y_R for ell_R=1. Indeed, for e=0 the
identity Uhat_block^2=1 forces sum_R ell_R=L mod 2, so the scalar above is
real. It follows that each block's eigenspaces have complete product
bases. In particular, for any nonnegative weights the minimum of F_w over
strongly symmetric states is zero and the full sector projector is fully
separable across this partition, so its F_w also vanishes.

Thus, with all weights w_R=1/2, the sector projector has exactly
E_3=(3/2)h when e=1 and E_3=0 when e=0. This does not assert that every
strongly symmetric state is separable when e=0: superpositions or mixed
states may still be entangled.

For example, on the six-site ring choose A={1,4}, B={2,5}, C={3,6}. All
three edge parities are even, and the state

    (|00>+|11>)_A (|00>+|11>)_B (|00>+|11>)_C / sqrt(8)

is a fully separable +1 eigenstate across these parties. The original
paper already observes that some disconnected tripartitions admit
symmetry-preserving products, so this is a parity-based extension, not a
counterexample to its connected-region theorem.

## Approximate sector and an exact noise threshold

Let e=1, let Uhat be the involutory symmetry, P_-= (I-Uhat)/2, and
epsilon=Tr(P_- rho). The exact-sector bound implies the following for
any state, with no exact or weak symmetry assumption:

    F_w(rho) >= max{0, B_w-W h_2(min{sqrt(epsilon),1/2})},
    B_w=min{(W-w_max)log 2,W h}.

The corresponding inequality holds with P_+ and P_- exchanged, so
epsilon can be replaced on the right by min{epsilon,1-epsilon}. To prove
this, use the local complement-pair measurement. In an outcome block,
let delta be the P_- probability; projection of a pure outcome to P_+,
when delta<1, produces a unit vector at trace distance sqrt(delta).
Partial traces can only decrease trace distance. The two states have
qubit support in each party, so qubit entropy continuity bounds each
entropy difference by h_2(min{sqrt(delta),1/2}); at delta=1 the trivial
log 2 entropy bound applies. The capped binary-entropy function is
concave, and block projectors commute with P_-. Jensen's inequality,
first over blocks and then over an arbitrary pure-state ensemble, gives
the result. Audenaert's sharp entropy continuity bound is in
https://doi.org/10.1088/1751-8113/40/28/S18.

There is a sharper entanglement-witness threshold. In the symmetric V
block one has

    V=(XXY+XYX+YXX+YYY)/2.

For a product state, write its three XY Bloch vectors as (x_R,y_R).
Optimizing over C and using 2|x_R y_R|<=x_R^2+y_R^2<=1 gives

    |<V>| <= 1/2 sqrt[(x_A y_B+y_A x_B)^2
                         +(x_A x_B+y_A y_B)^2] <= 1/sqrt(2).

Local complement-block measurements preserve products, so the same
inequality holds for arbitrary tripartite-separable physical states:

    |Tr(Uhat rho)| <= 1/sqrt(2).

This witness is tight. Set Q=(X+Y)/sqrt(2) and R=(X-Y)/sqrt(2).
Average all sign triples (a,b,c) with abc=1 over the two product-axis
choices (Q,Q,Q) and (R,R,-R), with each of the resulting eight product
pure states equally weighted. The average is (I+V/sqrt(2))/8.
A local Z flips V and gives the negative threshold, and convex mixing
gives all intermediate values. Transport the construction by the local
unitaries on each orbit block and average over blocks. Consequently,

    rho_t=(I+t Uhat)/2^L is tripartite-separable
                   if and only if |t|<=1/sqrt(2).           (4)

For e=0, rho_t is separable for the entire physical range |t|<=1.
The bound for a general rho is only a sufficient entanglement witness;
(4) is a necessary-and-sufficient statement for this particular
one-parameter family. It is not a spatial local-noise threshold.

The threshold is not new at the encoded three-qubit level. In fact,
after local conjugation, rho_t is exactly the state family with every
diagonal 1/8 and rho_18=rho_27=rho_36=-rho_54=t/8 studied by Chen,
Jiang, Yu and Tian, https://arxiv.org/html/1204.5511: their Eq. (17)
gives the nontrivial separability boundary 1/sqrt(2), and they further
compute its relative entropy of entanglement. General GHZ-diagonal
separability results were also obtained by Han and Kye,
https://arxiv.org/abs/1608.01908. The mapping to a CZX ring and its
arbitrary-party parity classification are the additional ingredients.
The source PRX Appendix B computes a permutation-criterion trace norm at
t=1; applying the same calculation to a normalized, locally postselected three-qubit block gives ||R(rho_t)||_1=1/2+|t|/sqrt(2). The raw unpostselected full-ring norm need not have this value.

## Evidence and prior overlap

The command python diagnostics/check_czx.py checks all
ordered contiguous partitions and complement-pair blocks for L=3,...,10
(7,423 blocks), including the signs, physical sector mapping,
orthogonality, and the two kinds of saturating basis. The general proof is
analytic; the finite checks are diagnostics. optimize_czx.py independently
searches the full L=4 and L=6 sectors numerically and finds the conjectured
value; a numerical search is not a lower-bound proof.
The additional command python diagnostics/check_disconnected.py
checks all 732 nonempty labeled tripartitions at L=3,...,6 and all their
4,998 complement blocks: 2,184 have e=0 and 2,814 have e=1. It verifies
the parity rule, physical-sector mapping, and appropriate complete
product or balanced eigenbases.
The command python diagnostics/check_robustness.py checks
symbolically the eight-product-state decomposition and the spectrum of
the realigned density matrix for all real t.

The strongest direct overlap is the source's Appendix A: its Eq. (A1)
defines the unweighted measure, Eq. (A2) its convex roof, and it states
the sharp minimum as a numerical conjecture, already presenting a full
basis of candidate minimizers and the resulting upper bound for the
sector projector. Its Sec. III B and Theorem 1 prove exact
tripartite nonseparability for CZX and more general anomalous symmetries;
we do not claim that qualitative theorem. Its Appendix B gives an
independent permutation-criterion witness for a small system.

Szalay, Phys. Rev. A 92, 042329 (2015),
https://doi.org/10.1103/PhysRevA.92.042329, gives the multipartite
entanglement-measure framework. Vollbrecht and Werner, Phys. Rev. A 64,
062307 (2001), https://doi.org/10.1103/PhysRevA.64.062307, give earlier
symmetry methods for convex-roof entanglement. Else and Nayak,
https://arxiv.org/abs/1409.5436, establish the anomalous-boundary
framework. These are methodological/background antecedents, not checked
equivalents of (1)–(2). A few targeted searches did not reveal an
independent exact solution, but this cannot establish priority or
journal significance.
