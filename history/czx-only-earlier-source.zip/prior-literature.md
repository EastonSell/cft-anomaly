# CZX convex-roof entropy: focused priority audit

Search date 27 October 2026. This note is a bounded literature audit, not a
novelty certification or an independent validation of the proposed proof.
The candidate examined is `work/research-czx-entropy/proof.md`: a lower
bound on the convex roof of a nonnegative weighted sum of three marginal
entropies in a strongly symmetric CZX charge sector, with equality for a
normalized full sector projector. Its even-ring connected-region result
specializes to the source's E3 conjecture. It also proposes a weighted
extension and an edge-parity classification for disconnected partitions.

## The direct antecedent and exactly what it settles

Lessa, Cheng, and Wang, [*Mixed-State Quantum Anomaly and Multipartite
Entanglement*](https://arxiv.org/html/2401.17357), PRX 15, 011069 (2025),
Appendix A, defines `E_3(|psi>)=(S_A+S_B+S_C)/2` and its mixed-state
convex roof. The published paper calls these Eqs. (A1) and (A2); the arXiv
HTML numbers them (64) and (65). In the paragraph after those definitions
it says that random sampling motivates the **conjecture** of an
L-independent CZX-sector minimum near `0.9 log 2`. It presents an entire
orthonormal basis of candidates, published Eqs. (A3)–(A8), whose value is

    (3/2) h_2((2+sqrt(2))/4) = 0.901314... log(2).

By averaging this basis, it obtains the corresponding upper bound on the
convex roof of the maximally mixed charge-sector state, and explicitly
states that equality is conditional on the conjectured global minimum.
The exact constant, these candidate vectors, and the upper bound therefore
are **not** new. The possible contribution of the current candidate is the
universal lower bound, plus its weighted and parity consequences, if its
proof withstands checking.

The source proves much more than an unexplained numerical observation:
Sec. III B gives CZX tripartite nonseparability and a complete basis of
states separable across any prescribed connected bipartition. Its Theorem 1
gives general anomalous-symmetry nonseparability and a finite-depth-channel
statement under its geometric/size hypotheses. Its Fig. 4 and discussion
already warn that disconnected partitions can evade the argument. The
candidate's precise even/odd boundary-edge criterion is a more specific
claim, not a new observation that *some* disconnected partitions differ.

Terminology matters: `E_3>0` witnesses failure of **full** separability
across A|B|C, not necessarily genuine multipartite entanglement in the
standard sense of being outside every mixture of biseparable states. The
source's own pure states separable across A|BC can have E3=log 2. In the
candidate, strong symmetry means `U rho=lambda rho`, not merely
`[U,rho]=0`; a lower bound for each charge sector does not automatically
apply to the full maximally mixed state, which is separable.

## Anticommutation and entropy: strong prior method overlap

Wehner and Winter, [*Higher entropic uncertainty relations for
anti-commuting observables*](https://arxiv.org/abs/0710.1185), J. Math.
Phys. 49, 062105 (2008), primary [full paper](https://qutech.nl/wp-content/uploads/2017/03/Higher-entropic-uncertainty-relations-for-anti-commuting-observables-1.pdf),
Lemma 2 proves `sum_j <Gamma_j>^2<=1` for a mutually anticommuting family.
Theorem 4 explicitly uses concavity of
`f(t)=h_2((1+sqrt(t))/2)` and optimization at extreme points to obtain the
optimal binary Shannon-entropy sum. The paper's appendix proves this same
concavity by differentiating. Thus neither the quadratic anticommutation
bound nor the entropy-concavity/extreme-point proof strategy should be
presented as new.

Their observables form **one common anticommuting family**, with a simplex
constraint on all squared expectations. The candidate instead obtains
three pairwise inequalities, involving conjugated, state-dependent local
observables; its feasible outer polytope has the fractional vertex
`(1/2,1/2,1/2)`, which would violate a full three-observable clique
constraint. Hence Wehner–Winter's theorem does not by itself give the
candidate's balanced entropy or the CZX-sector convex roof. The relation
requires a separate argument; merely drawing a triangle anticommutation
graph would incorrectly imply an extra three-variable constraint.
Applied separately to each of the three pairs in the candidate, Theorem 4
does give the weaker unweighted bound `E_3 >= (3/4) log(2)`; it does not
on its own give the proposed `(3/2)h` value. Wehner–Winter use base-two
measurement entropies and their theorem reads
`min_rho sum_j H(Gamma_j|rho) = K-1` for a common family of K.

Xu, Schwonnek and Winter, [*Bounding the joint numerical range of Pauli
strings by graph parameters*](https://arxiv.org/html/2308.00753), PRX
Quantum 5, 020318 (2024), final discussion, defines fractional packing by
nonnegative x and clique inequalities and explicitly proposes using it in
entropic uncertainty. It derives a linear lower bound on a sum of binary
measurement entropies, in bits, `sum H_i >= n-alpha*(G)`. This is an
important preexisting graph-polytope technique, though its clique
constraints for one fixed family cannot simply be imposed on the CZX
three-variable reduction. The manuscript does not state the proposed CZX
constant, connected-interval theorem, weighted marginal von Neumann
entropy, or sector roof.

Xu et al., [*Simultaneous variances of Pauli strings, weighted independence
numbers, and a new kind of perfection of graphs*](https://arxiv.org/html/2511.13531),
Eq. (34), treat weighted variance inequalities
`sum_i w_i Var(S_i)>=sum_i w_i-beta(G,w)` and graph-polytope optimization.
They optimize variance, not the entropy functional in the target claim;
their weighted graph methods are prior methodological overlap.

## Prior quantitative symmetry and convex-roof work

* Moharramipour, Lessa, Wang, Hsieh and Sahu, [*Symmetry enforced
  entanglement in maximally mixed states*](https://arxiv.org/html/2406.08542),
  PRX Quantum 5, 040336 (2024), Eq. (16), give an exact bipartite
  entanglement-of-formation/distillation expression for the maximally
  mixed invariant sector of an **on-site** compact symmetry. For on-site
  Abelian symmetries the invariant-sector state is separable. The paper's
  on-site factorization is unavailable for the non-on-site CZX action and
  it does not calculate the three-region `E_3` roof. This is a close
  physical and methodological antecedent, including two of the original
  authors.
* Li and Zou, [*Symmetry-enforced minimal entanglement and correlation in
  quantum spin chains*](https://arxiv.org/html/2412.20765), SciPost Phys.
  19, 020 (2025), Theorem 3 and Eqs. (58)–(60), obtain an explicit
  min-of-two-branches sharp Renyi-entropy bound for translation- and
  SO(3)-symmetric integer-spin uniform MPS in the stated large-segment
  setting. It is a pure-state bipartite / MPS result, with different
  symmetry and asymptotics, not a CZX tripartite mixed convex roof.
* Li, Lee and Yoshida, [*How Much Entanglement Is Needed for Topological
  Codes and Mixed States with Anomalous Symmetry?*](https://arxiv.org/html/2405.07970),
  PRX 15, 021090 (2025), prove quantitative bounds for convex-roof
  geometric entanglement associated with higher-form anomalies and
  topological codes. Their resource, dimension and anomaly assumptions
  differ from the entropy-sum CZX question.
* Lessa and Lu, [*Mixed-State Long-Range Entanglement from Dimensional
  Constraints*](https://arxiv.org/html/2605.15201), use the CZX state as a
  qualitative comparator; their main new projector is the
  translation-invariant subspace (Eq. (1)). They do not compute the CZX
  E3 convex roof in the inspected discussion.
* Szalay, [*Multipartite entanglement measures*](https://arxiv.org/abs/1503.06071),
  PRA 92, 042329 (2015), gives the earlier general hierarchy and
  entropy-based multipartite convex-roof framework cited by Lessa et al.
  Vollbrecht and Werner, [*Entanglement Measures under Symmetry*](https://arxiv.org/abs/quant-ph/0010095),
  PRA 64, 062307 (2001), give the classic symmetry-based convex-roof
  reduction, with exact results for other symmetry classes. Neither
  source is a checked equivalent of the targeted CZX numerical constant.

## Exact local-unitary identification and prior computation on the same state

In the encoded three-qubit reduction, let

    V = i (XXX) CZ_AB CZ_BC CZ_CA,
    rho_plus = (I+V)/8.

Direct expansion gives

    V = (YXX+XYX+XXY+YYY)/2.

Conjugate all three qubits by `R=exp(i*pi*Z/4)`. With the standard
Pauli conventions,

    (R^tensor3) V (R^tensor3)^dagger
      = V' = (XXX+XYY+YXY+YYX)/2.

Consequently the normalized projector `(I+V')/8` is a rank-four
three-qubit GHZ-diagonal state. These are independent calculations: they
are included to identify the prior family, not claimed as a literature
result. A direct matrix check was made. Moreover, this exact `V'` appears
as the Toffoli hypergraph stabilizer `S_7` in Vigliar et al.,
[*Error protected qubits in a silicon photonic chip*](https://arxiv.org/html/2009.08339),
Supplementary Table 6. That experimental paper studies a pure hypergraph
state and does not by that fact compute our projector's E3.

Conjugating `(I+V')/8` further by `I tensor X tensor X` yields, in the
canonical 000,...,111 basis,

    rho_ii = 1/8 for all i,
    rho_18 = rho_27 = rho_36 = +1/8,
    rho_54 = -1/8,

with all other off-diagonal entries zero except Hermitian conjugates. The
negative-sector projector is related by a local Z and has the same
local-unitary-invariant measures. This is also *literally* the normalized
eight-by-eight block already displayed by Lessa, Cheng and Wang in their
[Appendix B Eq. (72)](https://arxiv.org/html/2401.17357), apart from their
overall `2^-4` normalization for the block within the full four-qubit
state. No local-unitary argument is required to compare that displayed
matrix with earlier three-qubit work. It is precisely the symmetric,
equal-diagonal case in Chen, Jiang, Yu and Tian,
[*Entanglement and genuine entanglement of three-qubit
Greenberger-Horne-Zeilinger diagonal states*](https://arxiv.org/html/1204.5511),
following their Eq. (19). The later journal title is *Necessary and
sufficient fully separable criterion and entanglement of three-qubit
Greenberger–Horne–Zeilinger diagonal states*, Quantum Information
Processing 14, 2463–2476 (2015),
[doi:10.1007/s11128-015-0990-4](https://doi.org/10.1007/s11128-015-0990-4).
For their family with `rho_54=-rho_18`, their
solution has `theta=pi/4`; substituting `rho_18=1/8` into their displayed
relative-entropy formula gives the exact value, in bits,

    E_R(rho_plus) = log_2[2/(1+1/sqrt(2))]
                  = 0.228446696836388... .

This is a particularly strong antecedent: the *same rank-four state*,
the `1/sqrt(2)` parameter, an exact optimization and full nonseparability
were already studied. But their Eq. (18) minimizes the relative entropy
`S(rho||sigma)` over fully separable `sigma`. It is **not** the convex
roof of the sum of marginal von Neumann entropies; in particular its
numeric answer differs from the conjectured E3 value `0.901314...` bits.
The source's separability and relative-entropy computations alone do not
prove the claimed E3 minimum over all pure vectors in the support.

There is also an elementary qualitative implication from their witness:
for product states, `|<V'>|<=1/sqrt(2)` with equality. To see this, the
maximum occurs with equatorial Bloch vectors; if their angles are
`a,b,c`, then the expectation is
`[cos(a) cos(b-c)+sin(a) sin(b+c)]/2`, whose absolute value is at most
`1/sqrt(2)`, attained for `a=b=c=pi/4`. Thus the +/-1 eigenspaces have
no product vectors; compactness gives a strictly positive pure-state E3
minimum on either encoded eigenspace. This is a qualitative inference,
not the sharp entropy calculation or the complete ring result.

The displayed relative-entropy value has an independent short check.
With `P=(I+V')/2` and `p=(1+1/sqrt(2))/2`, the witness shows every fully
separable `sigma` obeys `Tr(P sigma)<=p`. Measuring `{P,I-P}` in both
arguments of the relative entropy and using data processing gives
`D(P/4||sigma)>=-log_2(p)`. Conversely, the local-unitary GHZ twirl
generated by `ZZI`, `ZIZ`, and `XXX` sends the product state
`[(|0>+exp(i*pi/4)|1>)/sqrt(2)]^tensor3` to the fully separable state
`sigma_*=(I+V'/sqrt(2))/8 = p P/4+(1-p)(I-P)/4`, attaining the bound.
This reproduces the cited result and clarifies why its numerical value
and entropy target are different.

Independent direct comparison of other full texts:

* Han and Kye, [*Separability of three qubit
  Greenberger-Horne-Zeilinger diagonal states*](https://arxiv.org/html/1608.01908),
  give an iff full-separability criterion using witnesses; the full HTML
  has no entropy or convex-roof calculation. Their related
  [rank-four X-state theorem](https://arxiv.org/html/1610.06645),
  Theorem 3.3 and Eq. (13), imply qualitative nonseparability here:
  the necessary phase identity `c_1 c_4=c_2 c_3` fails for an odd number
  of negative anti-diagonal entries. Their 2021
  [GHZ-diagonal polytope analysis](https://arxiv.org/html/2104.07871)
  determines biseparability and full biseparability geometry and Bell
  inequalities; it does not calculate this entropy roof.
* Hofmann, Moroder and Guhne,
  [*Analytical characterization of the genuine multiparticle
  negativity*](https://arxiv.org/html/1401.2424), Corollary 7 Eq. (28),
  compute the genuine multipartite negativity of every GHZ-diagonal
  state as `max(0,F_max-1/2)`. Here `F_max=1/4`, so this measure is zero.
  It detects genuine multipartite entanglement, not failure of full
  separability, and is not E3.
* Burduli, Moerland and Schupp,
  [*Multipartite GHZ diagonal states and their entanglement
  properties*](https://arxiv.org/html/2609.28351), 23 September 2026,
  Eqs. (85)–(86) and (96)–(99), characterize fully separable
  GHZ-diagonal geometry using depolarized products, with examples. Its
  text does not calculate a sum-of-marginal-entropies convex roof.
* Payn and Girolami,
  [*Observable measures of multipartite entanglement*](https://arxiv.org/html/2605.01375),
  Eqs. (14)–(20), combine independently minimized *bipartite* E_Fs,
  whose corresponding terms vanish on the encoded state because it is
  separable across each bipartition. In contrast the roof of the *sum*
  forces one common ensemble and can be strictly positive. Their
  dephased GHZ calculation in Eqs. (21)–(24) concerns a distinct
  rank-two family.

Szalay's earlier [*Multipartite entanglement measures*](https://arxiv.org/html/1503.06071),
Sec. VI.3, explicitly displays the same pure measure
`E_1|2|3=(S_1+S_2+S_3)/2`; Eqs. (108) and (112) extend it by a convex
roof. The result also states its vanishing precisely characterizes full
separability. This fixes prior attribution of the **exact measure**,
although that paper does not give a checked numerical E3 for this state.

## Search coverage and residual uncertainty

Exact-title, CZX/E3, entropy-number, anticommuting-observable and weighted
uncertainty searches were run; selected direct source full texts are linked
above. OpenAlex returned 29 indexed citing works; Semantic Scholar returned
76 citing records, including 2026 preprints. These public metadata snapshots
are saved respectively as `czx-citing-openalex.json` and
`czx-citing-semantic-scholar.json`. Titles/available abstracts were screened
and the closest candidates were checked in their primary full texts; this
was **not** a full-text proof audit of all 76 papers. Search engines and
citation indexes are incomplete, especially for recent preprints and
equivalent results in different notation. No claim of priority follows from
failure to find a competing proof.
