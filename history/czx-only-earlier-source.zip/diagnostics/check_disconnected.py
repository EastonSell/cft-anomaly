"""Exact tests of the edge-parity classification for arbitrary partitions."""
from itertools import product

coords=list(product((0,1),repeat=3))
v0=[1,1,1,1j,-1j,1,1,1]

def bxor(a,b):
    return tuple(x^y for x,y in zip(a,b))

def inner(v,w):
    return sum(a.conjugate()*b for a,b in zip(v,w))

def image(v,q,odd):
    out=[0j]*8
    for j,t in enumerate(coords):
        out[coords.index(bxor(t,(1,1,1)))]=(-1)**q(t)*v[j]*(1j if odd else 1)
    return out

def qc(t):
    x,y,z=t
    return (x+x*y+y*z+z*x)%2

def reps(n):
    return [(0,)+t for t in product((0,1),repeat=n-1)]

balanced=[]
for u,v in product((0,1),repeat=2):
    balanced.append([(-1)**(u*(x+y)+v*(x+z))*v0[i]
                     for i,(x,y,z) in enumerate(coords)])
counts=[0,0]
for L in (3,4,5,6):
    odd=L%2
    partitions=0
    for labels in product((0,1,2),repeat=L):
        if len(set(labels))!=3:
            continue
        partitions+=1
        edgecount={(0,1):0,(1,2):0,(0,2):0}
        for i in range(L):
            pair=tuple(sorted((labels[i],labels[(i+1)%L])))
            if pair[0]!=pair[1]:
                edgecount[pair]^=1
        assert len(set(edgecount.values()))==1
        e=edgecount[(0,1)]
        sites=[tuple(i for i,x in enumerate(labels) if x==j) for j in range(3)]
        for repts in product(*(reps(len(s)) for s in sites)):
            seed=[0]*L
            for j in range(3):
                for pos,bit in zip(sites[j],repts[j]):
                    seed[pos]=bit
            def q(t):
                b=[seed[i]^t[labels[i]] for i in range(L)]
                return sum(b[i]*b[(i+1)%L] for i in range(L))%2
            q0=q((0,0,0))
            ell=tuple(q0^q(tuple(int(j==i) for j in range(3))) for i in range(3))
            for t in coords:
                x,y,z=t
                assert q(t)==(q0+sum(a*b for a,b in zip(ell,t))+
                              e*(x*y+y*z+z*x))%2
            assert sum(ell)%2==(odd^e)
            if e==1:
                def qt(t): return q(t)^(odd*t[0])^odd
                s=next(s for s in coords if all(
                    qt(bxor(t,s))==(qt(s)^qc(t)) for t in coords))
                for sector in (0,1):
                    basis=[]
                    h=qt(s)^sector
                    for original in balanced:
                        w=[0j]*8
                        for i,t in enumerate(coords):
                            out=bxor(t,s)
                            diag=(-1j if out[0] else 1) if odd else 1
                            w[coords.index(out)]=diag*(-1)**(h*t[0])*original[i]
                        assert image(w,q,odd)==[(-1)**sector*z for z in w]
                        basis.append(w)
                    for i in range(4):
                        for j in range(4):
                            assert inner(basis[i],basis[j])==(8 if i==j else 0)
            else:
                sectorbases={1:[],-1:[]}
                for signs in product((1,-1),repeat=3):
                    vec=[(signs[0]*(1j if ell[0] else 1))**x *
                         (signs[1]*(1j if ell[1] else 1))**y *
                         (signs[2]*(1j if ell[2] else 1))**z
                         for x,y,z in coords]
                    out=image(vec,q,odd)
                    sector=out[0]/vec[0]
                    assert sector in (1,-1)
                    assert out==[sector*z for z in vec]
                    sectorbases[sector].append(vec)
                for basis in sectorbases.values():
                    assert len(basis)==4
                    for i in range(4):
                        for j in range(4):
                            assert inner(basis[i],basis[j])==(8 if i==j else 0)
            counts[e]+=1
    print('L',L,'nonempty labelled partitions',partitions)
print('blocks checked, e=0 and e=1:',counts)
print('all exact checks pass')
