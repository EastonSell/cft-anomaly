"""Exact finite checks of the CZX orbit-block reduction and minimizing basis.

This checks representative finite rings; the general argument is analytic.
All amplitudes below omit a common normalization 1/sqrt(8).
"""
from itertools import product
from fractions import Fraction
from math import sqrt, log


def dot(a, b):
    return sum(x*y for x,y in zip(a,b))


def bxor(a, b):
    return tuple(x^y for x,y in zip(a,b))


coords=list(product((0,1),repeat=3))
v0=[1,1,1,1j,-1j,1,1,1]


def qcanon(t):
    x,y,z=t
    return (x+x*y+y*z+z*x)%2


def pair_inner(v,w):
    return sum(a.conjugate()*b for a,b in zip(v,w))


def image(v,q):
    out=[0j]*8
    for i,t in enumerate(coords):
        j=coords.index(bxor(t,(1,1,1)))
        out[j]=(-1)**q(t)*v[i]
    return out


assert image(v0,qcanon)==v0
for i in range(3):
    # Reduced encoded qubit: diagonal 1/2, |offdiagonal|^2=1/8.
    off=0j
    for t in coords:
        if t[i]==0:
            s=list(t);s[i]=1;s=tuple(s)
            off+=v0[coords.index(t)]*v0[coords.index(s)].conjugate()
    assert off.real**2+off.imag**2==8
    print(f'party {i}: reduced eigenvalues (1 +/- 1/sqrt(2))/2')

# Four mutually orthogonal biseparable C-versus-AB states. Their common
# normalization is 1/2, and party C is pure while A and B are maximally mixed.
bellbasis=[
    [1,1,0,0,0,0,1,1],
    [1,-1,0,0,0,0,-1,1],
    [0,0,1,1j,-1j,1,0,0],
    [0,0,1,-1j,1j,1,0,0],
]
for i,v in enumerate(bellbasis):
    assert image(v,qcanon)==v
    for j,w in enumerate(bellbasis):
        assert pair_inner(v,w)==(4 if i==j else 0)
    for ax in range(3):
        rho=[[0j,0j],[0j,0j]]
        for t in coords:
            for r in (0,1):
                s=list(t);s[ax]=r;s=tuple(s)
                rho[t[ax]][r]+=v[coords.index(t)]*v[coords.index(s)].conjugate()
        # purity = Tr rho^2; all entries carry a factor 1/4
        pur=sum(rho[j][k]*rho[k][j] for j in range(2) for k in range(2))
        assert pur==(16 if ax==2 else 8)
print('four-state biseparable saturating basis passes')


def reps(n):
    return [(0,)+s for s in product((0,1),repeat=n-1)]


blocks=0
balancedbasis=[]
for u,v in product((0,1),repeat=2):
    balancedbasis.append([(-1)**(u*(x+y)+v*(x+z))*v0[i]
                          for i,(x,y,z) in enumerate(coords)])
for L in (3,4,5,6,7,8,9,10):
    for a in range(1,L-1):
        for b in range(1,L-a):
            c=L-a-b
            for aa,bb,cc in product(reps(a),reps(b),reps(c)):
                seed=aa+bb+cc
                sizes=(a,b,c)
                def q(t):
                    i=0;bits=[]
                    for n,x in zip(sizes,t):
                        bits.extend(v^x for v in seed[i:i+n])
                        i+=n
                    return sum(bits[j]*bits[(j+1)%L] for j in range(L))%2
                q0=q((0,0,0))
                ell=tuple(q0^q(tuple(int(j==i) for j in range(3)))
                          for i in range(3))
                odd=L%2
                assert sum(ell)%2==(1^odd)
                for t in coords:
                    x,y,z=t
                    assert q(t)==(q0+dot(ell,t)+x*y+y*z+z*x)%2
                    assert q(t)^q(bxor(t,(1,1,1)))==odd
                # For odd L rephase U by i, and conjugate by S_A.
                # The resulting signed-complement phase has odd ell.
                def qt(t):
                    return q(t)^(odd*t[0])^odd
                # A local X translates ell to (1,0,0), up to sign.
                s=next(s for s in coords if all(
                    qt(bxor(t,s))==(qt(s)^qcanon(t)) for t in coords))
                for sector_bit in (0,1):
                    h=qt(s)^sector_bit
                    for prototype,norm2 in ((balancedbasis,8),(bellbasis,4)):
                        basis=[]
                        for original in prototype:
                            w=[0j]*8
                            for i,t in enumerate(coords):
                                out=bxor(t,s)
                                # undo S_A in odd-L case
                                diagonal=(-1j if out[0] else 1) if odd else 1
                                w[coords.index(out)]=diagonal*(-1)**(h*t[0])*original[i]
                            expected=(-1)**sector_bit
                            actual=image(w,q)
                            if odd:
                                actual=[1j*z for z in actual]
                            assert actual==[expected*z for z in w]
                            basis.append(w)
                        for i in range(4):
                            for j in range(4):
                                assert pair_inner(basis[i],basis[j])==(norm2 if i==j else 0)
                blocks+=1
    print(f'L={L}: all ordered contiguous partitions and complement blocks pass')

# Exact polytope vertices: x,y,z>=0, pairwise sums <=1.
# For any x,y,z let m=min(x,y,z), weights:
# lambda_half=2m, lambda_i=x_i-m, lambda_zero=1-(sum(x)-m).
# Pairwise sums <=1 make all weights nonnegative.
for x,y,z in product([Fraction(i,10) for i in range(11)],repeat=3):
    if max(x+y,y+z,z+x)>1:
        continue
    m=min(x,y,z)
    weights=[1-(x+y+z-m),x-m,y-m,z-m,2*m]
    assert min(weights)>=0 and sum(weights)==1
    assert weights[1]+weights[4]/2==x
    assert weights[2]+weights[4]/2==y
    assert weights[3]+weights[4]/2==z
p=(2+sqrt(2))/4
E=1.5*(-p*log(p)-(1-p)*log(1-p))
print('checked blocks:',blocks)
print('attained E3 =',E,'=',E/log(2),'log(2)')
print('weighted crossing max(w_i)/sum(w_i) =',1-(E/1.5)/log(2))
