#!/usr/bin/env python3
"""Portable exact-arithmetic diagnostics for the CZX three-party result.

Run with Python 3.9+ and only the standard library:
    python check_czx_exact.py

The finite exhaustive tests at L <= 7 and exact 3-qubit identities support,
but cannot replace, the paper's analytic all-L parity and witness proofs.
There are no numerical tolerances: arithmetic is in Q(sqrt(2), i).
"""
from fractions import Fraction as F
from itertools import product

# a + b sqrt(2) + i(c + d sqrt(2)).
def q(a=0, b=0, c=0, d=0):
    return tuple(F(x) for x in (a, b, c, d))

ZERO, ONE, I, ROOT = q(), q(1), q(c=1), q(b=1)

def add(x, y):
    return tuple(a+b for a, b in zip(x, y))

def neg(x):
    return tuple(-a for a in x)

def mul(x, y):
    a,b,c,d=x
    e,f,g,h=y
    return (a*e+2*b*f-c*g-2*d*h,
            a*f+b*e-c*h-d*g,
            a*g+2*b*h+c*e+2*d*f,
            a*h+b*g+c*f+d*e)

def scale(x, y):
    return tuple(F(y)*a for a in x)

def conj(x):
    return (x[0],x[1],-x[2],-x[3])

def pow_i(n):
    return (ONE, I, neg(ONE), neg(I))[n % 4]

def matadd(A,B):
    return [[add(a,b) for a,b in zip(ra,rb)] for ra,rb in zip(A,B)]

def matscale(A,c):
    return [[scale(x,c) for x in row] for row in A]

def kron(A,B):
    return [[mul(A[i//len(B)][j//len(B[0])], B[i%len(B)][j%len(B[0])])
             for j in range(len(A[0])*len(B[0]))]
            for i in range(len(A)*len(B))]

def trace_product(A,B):
    s=ZERO
    for i in range(len(A)):
        for j in range(len(A)):
            s=add(s,mul(A[i][j],B[j][i]))
    return s

IDENTITY=[[ONE,ZERO],[ZERO,ONE]]
X=[[ZERO,ONE],[ONE,ZERO]]
Y=[[ZERO,neg(I)],[I,ZERO]]
ID8=kron(kron(IDENTITY,IDENTITY),IDENTITY)

def pauli(A,B,C):
    return kron(kron(A,B),C)

def triangle(x):
    return (x[0]*x[1]+x[1]*x[2]+x[0]*x[2])%2

bits=list(product((0,1),repeat=3))
V=[[ZERO for _ in bits] for _ in bits]
for j,x in enumerate(bits):
    k=bits.index(tuple(1-v for v in x))
    V[k][j]=neg(I) if triangle(x) else I

# Algebraic Pauli expansion and Hermiticity, exactly.
pauli_sum=matadd(matadd(pauli(X,X,Y),pauli(X,Y,X)),
                 matadd(pauli(Y,X,X),pauli(Y,Y,Y)))
assert V==matscale(pauli_sum,F(1,2))
assert all(V[i][j]==conj(V[j][i]) for i in range(8) for j in range(8))

def equatorial(xsign,ysign):
    """Density matrix with Bloch components (xsign, ysign)/sqrt(2)."""
    z=q(b=F(xsign,4),d=F(-ysign,4))
    return [[q(F(1,2)),z],[conj(z),q(F(1,2))]]

# Eight product states at the separability threshold; exact equality.
ensemble=[[ZERO for _ in range(8)] for _ in range(8)]
states=0
for u in (-1,1):
    for s in product((-1,1),repeat=3):
        if s[0]*s[1]*s[2]!=1:
            continue
        local=[equatorial(u*v,v) for v in s]
        ensemble=matadd(ensemble,kron(kron(local[0],local[1]),local[2]))
        states+=1
assert states==8
ensemble=matscale(ensemble,F(1,8))
target=matadd(matscale(ID8,F(1,8)),
              [[mul(q(b=F(1,16)),v) for v in row] for row in V])
assert ensemble==target  # (I+V/sqrt(2))/8.
# Also check the equivalent parameterization used in the manuscript:
# (x,y)=(s_j,r*s_j)/sqrt(2), with s_A*s_B*s_C=r.
manuscript_ensemble=[[ZERO for _ in range(8)] for _ in range(8)]
for r in (-1,1):
    for s in product((-1,1),repeat=3):
        if s[0]*s[1]*s[2]!=r:
            continue
        local=[equatorial(v,r*v) for v in s]
        manuscript_ensemble=matadd(manuscript_ensemble,
                                   kron(kron(local[0],local[1]),local[2]))
assert matscale(manuscript_ensemble,F(1,8))==target
# Conjugating every product term by Z on the first party yields the
# negative endpoint (I-V/sqrt(2))/8, without losing separability.
negative=[[ZERO for _ in range(8)] for _ in range(8)]
for u in (-1,1):
    for s in product((-1,1),repeat=3):
        if s[0]*s[1]*s[2]!=1:
            continue
        local=[equatorial(u*v,v) for v in s]
        local[0]=equatorial(-u*s[0],-s[0])
        negative=matadd(negative,kron(kron(local[0],local[1]),local[2]))
negative=matscale(negative,F(1,8))
assert negative==matadd(matscale(ID8,F(1,8)),
                        [[neg(mul(q(b=F(1,16)),v)) for v in row] for row in V])

# The extremal product |pi/4>^tensor 3 attains <V>=1/sqrt(2).
plus=equatorial(1,1)
product_state=kron(kron(plus,plus),plus)
assert trace_product(V,product_state)==q(b=F(1,2))

# Physical four-site example A={0,1}, B={2}, C={3}. In the all-zero
# complement block, U has q=x_A+x_A*x_B+x_B*x_C+x_C*x_A. The product
# on A has logical phase -pi/4; B and C each have phase pi/4.
U100=[[ZERO for _ in bits] for _ in bits]
for j,x in enumerate(bits):
    k=bits.index(tuple(1-v for v in x))
    U100[k][j]=neg(ONE) if (x[0]+triangle(x))%2 else ONE
physical=kron(kron(equatorial(1,-1),plus),plus)
assert trace_product(U100,physical)==q(b=F(1,2))

def xor_bits(v):
    return tuple(1-z for z in v)

def all_blocks(colours):
    """Choose one rep from each local bitstring/complement pair."""
    locations=[[j for j,c in enumerate(colours) if c==r] for r in range(3)]
    # Each region is nonempty. Fix its first bit to zero to choose a rep.
    free=[j for loc in locations for j in loc[1:]]
    for values in product((0,1),repeat=len(free)):
        base=[0]*len(colours)
        for j,v in zip(free,values):
            base[j]=v
        yield base

def qphysical(base,colours,x):
    ring=[base[j]^x[colours[j]] for j in range(len(base))]
    return sum(ring[j]*ring[(j+1)%len(ring)] for j in range(len(ring)))%2

counts=[0,0]
for n in range(3,8):
    for colours in product(range(3),repeat=n):
        if len(set(colours))!=3:
            continue
        cross=[]
        for a,b in ((0,1),(1,2),(2,0)):
            cross.append(sum({colours[j],colours[(j+1)%n]}=={a,b}
                             for j in range(n))%2)
        assert cross[0]==cross[1]==cross[2]
        e=cross[0]
        for base in all_blocks(colours):
            q0=qphysical(base,colours,(0,0,0))
            ell=tuple(qphysical(base,colours,tuple(int(j==a) for j in range(3)))^q0
                      for a in range(3))
            for x in bits:
                predicted=q0
                predicted^=sum(ell[j]*x[j] for j in range(3))%2
                predicted^=e*triangle(x)
                assert qphysical(base,colours,x)==predicted
                # The odd-ring rephasing Uhat=i U makes its square +I.
                flip=tuple(1-v for v in x)
                assert (qphysical(base,colours,x)+qphysical(base,colours,flip))%2==n%2
                if not e:
                    # With e=0 the block factors into three one-party
                    # X Z^ell actions, up to an overall unit phase.
                    block=pow_i((n%2)+2*qphysical(base,colours,x))
                    factor=pow_i((n%2)+2*q0+2*sum(ell[j]*x[j]
                                                       for j in range(3)))
                    assert block==factor
            # For odd crossing parity, check exact local-unitary conjugacy
            # to V: D=⊗diag(1,i**ell_j), up to a block-wide sign.
            # Uhat=i^(n mod 2) U has coefficient i^(n mod 2)(-1)^q(x).
            if e:
                src=pow_i((n%2)+2*q0)
                tgt=pow_i(1+sum(ell))
                ratio=mul(src,conj(tgt))
                assert ratio in (ONE,neg(ONE))
                for x in bits:
                    lhs=pow_i((n%2)+2*qphysical(base,colours,x))
                    # D V D^dagger at row complement(x), column x.
                    exponent=1+2*triangle(x)+sum(ell[j]*(1-2*x[j])
                                                 for j in range(3))
                    assert lhs==mul(ratio,pow_i(exponent))
            counts[e]+=1

print('Exact Q(sqrt(2),i) identities: V Pauli expansion, 8-state decomposition,')
print('  logical and physical witness saturators: PASS')
print(f'Exhaustive ring complement blocks for L=3..7: even={counts[0]}, odd={counts[1]}: PASS')
print('All-L validity and the 1/sqrt(2) upper bound are analytic statements,')
print('  not established by these finite checks.')
