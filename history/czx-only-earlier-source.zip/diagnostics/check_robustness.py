"""Exact symbolic checks for the noisy three-qubit CZX block."""
import sympy as s
from itertools import product

I=s.eye(2)
X=s.Matrix([[0,1],[1,0]])
Y=s.Matrix([[0,-s.I],[s.I,0]])
Z=s.diag(1,-1)
kron=s.kronecker_product
V=(kron(X,X,Y)+kron(X,Y,X)+kron(Y,X,X)+kron(Y,Y,Y))/2
assert V*V==s.eye(8)
Q=(X+Y)/s.sqrt(2)
R=(X-Y)/s.sqrt(2)
rho=s.zeros(8)
for axes in ((Q,Q,Q),(R,R,-R)):
    for signs in product((1,-1),repeat=3):
        if signs[0]*signs[1]*signs[2]!=1:
            continue
        factors=[(I+sgn*axis)/2 for sgn,axis in zip(signs,axes)]
        rho+=kron(*factors)/8
assert s.simplify(rho-(s.eye(8)+V/s.sqrt(2))/8)==s.zeros(8)
print('exact: 8-product-state decomposition at +1/sqrt(2)')
flip=kron(Z,I,I)
assert flip*V*flip==-V
print('exact: local Z maps to the -1/sqrt(2) endpoint')

t=s.symbols('t',real=True)
density=(s.eye(8)+t*V)/8
realigned=s.zeros(8)
for a,b,c,A,B,C in product(range(2),repeat=6):
    realigned[4*a+2*b+c,4*A+2*B+C]=density[4*a+2*C+c,4*A+2*B+b]
spectrum=(realigned*realigned.conjugate().T).eigenvals()
assert spectrum=={s.Rational(1,16):2,s.Integer(0):2,t**2/32:4}
print('exact: realignment RR† eigenvalues',spectrum)
print('realignment trace norm = 1/2+|t|/sqrt(2)')
