# Audit of the approximate CZX symmetry bound

This note independently derives the proposed extension, conditional on
the exact-sector three-party entropy bound in
`work/research-czx/anticommutation-proof.md`. It is an internal audit,
not an independent human or specialist verification of that bound.

Use an even periodic chain, three nonempty connected arcs, the symmetry
involution \(U\), a sign \(\lambda\in\{+1,-1\}\), and nonnegative
weights \(w_R\). Let \(W=\sum_Rw_R\) and
\[
 M_w=\min\{(W-w_{\max})\log2,\;W h(p)\},\qquad
 p=\frac{2+\sqrt2}{4},
\]
where \(h(t)=-t\log t-(1-t)\log(1-t)\). Assume the previously
stated result that every pure \(U\)-eigenstate has weighted entropy
at least \(M_w\). For an arbitrary, possibly mixed, state \(\rho\), put
\[
 \varepsilon=\operatorname{tr}\!\left[\frac{I-\lambda U}{2}\rho\right],
 \qquad
 g(t)=h\bigl(\min\{\sqrt t,1/2\}\bigr). \tag{1}
\]
Then its weighted convex-roof entropy obeys
\[
 \boxed{\qquad F_w(\rho)\ge
 \max\{0,M_w-Wg(\varepsilon)\}.\qquad} \tag{2}
\]
This is dimension-independent because the qubit continuity estimate is
used *after* the complement-block measurement. Directly projecting a
state on a long physical chain and applying a dimension-dependent entropy
estimate would not justify (2).

## Pure states and local complement blocks

Let \(P_b\) be a product of the local complement-pair projectors on the
three arcs. Each \(P_b\) commutes with \(U\), their sum is identity, and
each nonzero block has dimension \(2\times2\times2\). For a pure state
\(|\psi\rangle\), let \(q_b=\langle\psi|P_b|\psi\rangle\), and, when
\(q_b>0\), write
\[
 |\psi_b\rangle=P_b|\psi\rangle/\sqrt{q_b},\qquad
 \delta_b=\langle\psi_b|(I-\lambda U)/2|\psi_b\rangle.
\]
Because the projectors commute,
\[
 \sum_b q_b\delta_b
 =\langle\psi|(I-\lambda U)/2|\psi\rangle. \tag{3}
\]
The block measurement is a sequence of local operations relative to the
three parties. For any bipartition \(R|\overline R\), concavity of the
entropy of the unmeasured side shows that its average post-measurement
pure-state entropy cannot increase. Therefore
\[
 F_w(\psi)\ge\sum_bq_bF_w(\psi_b). \tag{4}
\]

If \(\delta_b<1\), normalize the projection of \(|\psi_b\rangle\) onto
the \(\lambda\) eigenspace and call it \(|\phi_b\rangle\). It belongs to
the same complement block and
\(|\langle\psi_b|\phi_b\rangle|^2=1-\delta_b\). Thus the pure-state
trace distance is exactly \(\sqrt{\delta_b}\), and contractivity gives
the same upper bound for each reduced encoded qubit. The sharp qubit
entropy-continuity inequality, combined with the trivial \(\log2\)
entropy bound, gives
\[
 |S(\rho_R^{\psi_b})-S(\rho_R^{\phi_b})|
 \le h\bigl(\min\{\sqrt{\delta_b},1/2\}\bigr). \tag{5}
\]
The cap at \(1/2\) is essential when an upper bound on trace distance
exceeds \(1/2\), because binary entropy decreases above \(1/2\). If
\(\delta_b=1\), no normalized projection exists, but (5)'s right side
is \(\log2\) and \(F_w(\psi_b)\ge0\) already implies the lower bound
below. In either case,
\[
 F_w(\psi_b)\ge M_w-Wg(\delta_b). \tag{6}
\]

The function \(t\mapsto\min\{\sqrt t,1/2\}\) is concave and
nondecreasing, and \(h\) is concave and nondecreasing on \([0,1/2]\).
Hence \(g\) is concave and nondecreasing. Applying Jensen to (4), (6)
and using (3) proves (2) for pure \(\psi\), before the maximum with zero.

## Arbitrary mixed states and the positivity threshold

For any pure ensemble \(\rho=\sum_i r_i|\psi_i\rangle\langle\psi_i|\),
\(\sum_i r_i\varepsilon_i=\varepsilon\). The pure-state bound and a
second application of Jensen give
\[
 \sum_i r_iF_w(\psi_i)\ge
 M_w-W\sum_i r_i g(\varepsilon_i)
 \ge M_w-Wg(\varepsilon).
\]
The inequality therefore survives the infimum over all pure ensembles
defining the convex roof. No particular decomposition, purity, or exact
strong symmetry of \(\rho\) is assumed. Nonnegativity gives (2).

For \(E_3=\tfrac12\sum_R S(\rho_R)\), the balanced exact-sector
branch is the smaller one. Thus
\[
 E_3(\rho)\ge\frac32\max\{0,h(p)-g(\varepsilon)\}. \tag{7}
\]
The right side is strictly positive exactly when
\[
 \boxed{\quad\varepsilon<(1-p)^2
 =\frac{3-2\sqrt2}{8}=0.0214466094\ldots.\quad} \tag{8}
\]
Indeed, on \([0,1/2]\), \(h\) is strictly increasing, and
\(h(p)=h(1-p)\). The threshold is the exact positivity region of this
particular lower bound, not a claim that the true entanglement threshold
is sharp.

Both symmetry sectors have the same exact-sector minimum. Choosing the
nearer of the two sectors at the start of the proof gives the optional
stronger version with \(\min\{\varepsilon,1-\varepsilon\}\) in place
of \(\varepsilon\). This also gives positivity near the opposite charge
sector; it does not assume approximate symmetry in a fixed sign sector.

## A sharp positivity threshold from an arc-product witness

The continuity bound above is not the strongest consequence of the same
block structure. Suppose the three parties are the chosen arcs A, B and C;
"product" in this section means product across those arcs, not necessarily
product across every individual lattice site. The following statements
also hold for odd \(L\ge3\) after replacing \(U\) by the Hermitian
involution \(\widetilde U=iU\); for even \(L\) let \(\widetilde U=U\).

In every complement block the involution is locally unitarily equivalent,
up to a sign, to
\[
 V=\frac12(YXX+XYX+XXY+YYY). \tag{9}
\]
For a product of three encoded qubit states with planar Bloch components
\((x_R,y_R)\),
\[
 2\langle V\rangle
 =x_A(y_Bx_C+x_By_C)+y_A(x_Bx_C+y_By_C).
\]
Each coefficient of \(x_A,y_A\) has absolute value at most one by
Cauchy--Schwarz, and \(x_A^2+y_A^2\le1\). Thus
\(|\langle V\rangle|\le1/\sqrt2\). Equality is attained by choosing
\(x_R=y_R=1/\sqrt2\) for all three parties; a local \(Z\) changes its
sign. Local complement-block measurements preserve productness across
the three arcs and commute with \(\widetilde U\). Averaging their
outcomes, and then mixtures, proves the **sharp arc-separable witness**
\[
 |\operatorname{tr}(\widetilde U\rho)|\le1/\sqrt2
 \quad\text{for every A|B|C-separable }\rho. \tag{10}
\]
For long arcs, the encoded product saturators may be GHZ-type states
within an arc, so (10)'s sharpness is not a site-by-site separability
claim.

The witness gives an explicit convex-roof lower bound. For an arbitrary
pure \(|\psi\rangle\), choose a maximal-eigenvalue eigenvector of each
local reduced state, and form their product \(|abc\rangle\). The three
local rank-one projectors commute, so the union bound gives
\[
 1-|\langle abc|\psi\rangle|^2
 \le\sum_R(1-\lambda_{\max}(\rho_R))
 \le\sum_R S(\rho_R)=2E_3(\psi). \tag{11}
\]
The second inequality uses
\(S(\rho_R)\ge-\log\lambda_{\max}(\rho_R)
\ge1-\lambda_{\max}(\rho_R)\). The trace distance between the two
pure states is at most \(\sqrt{2E_3(\psi)}\), so (10) and
\(\|\widetilde U\|=1\) imply
\[
 E_3(\psi)\ge\frac18
 \bigl(|\langle\widetilde U\rangle_\psi|-1/\sqrt2\bigr)_+^2. \tag{12}
\]
The function \(s\mapsto(|s|-1/\sqrt2)_+^2\) is convex. Jensen over
every pure decomposition and the convex-roof infimum give, for all mixed
states,
\[
 \boxed{\qquad E_3(\rho)\ge\frac18
 \bigl(|\operatorname{tr}(\widetilde U\rho)|-1/\sqrt2\bigr)_+^2.
 \qquad} \tag{13}
\]
It may be combined by taking the maximum with (7), applied to the nearer
sector.

For \(\varepsilon=\operatorname{tr}[(I-\lambda\widetilde U)\rho]/2\),
(13) guarantees positive \(E_3\) whenever
\[
 \varepsilon<1-p=\frac{1-1/\sqrt2}{2}=0.1464466094\ldots
 \quad\text{or}\quad\varepsilon>p. \tag{14}
\]
These are the **sharp universal regions determined by leakage alone**:
mixing the two opposite-expectation encoded product states gives an
A|B|C-separable state with any prescribed
\(\varepsilon\in[1-p,p]\). Thus (14) cannot be extended as an
all-states positivity guarantee using only \(\varepsilon\). The numerical
lower bound (13), as opposed to its positivity threshold, is not asserted
to be optimal.
